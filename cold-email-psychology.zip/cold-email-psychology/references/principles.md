# Psychology Principles

**Ranking note: principles are ranked by how often they appear in the analyzed emails, not by proven reply rate. A frequent principle is common practice, not evidence that it works.** Listed by frequency across analyzed emails (final ranking). Counts are a judgment call per email. Emails analyzed so far: 1669 (6 Clay, 6 Apollo, 9 Salesloft, 75 Woodpecker, 17 ZoomInfo, 3 Coursera, 8 FirstSales, 19 Smartlead, 21 SmartWriter, 15 Cognism, 12 LeadsMonky, 15 Warmupinbox, 22 HubSpot, 12 Proposify, 510 Hunter, 32 Saleshandy, 129 SmartReach, 16 Breakcold, 9 Truelist, 10 Datalane, 10 Salesforge, 31 Salesbread, 12 DemandCurve, 10 Outplay, 15 Cleverly, 15 Artisan, 33 Mailsuite, 32 Reachly, 20 LeadSquared, 8 Salesdorado, 15 TextMagic, 12 ProProfsDesk, 18 BluLeadz, 25 Waalaxy, 22 Clearout, 11 LeadGibbon, 7 Starnus, 8 MailGenius, 15 Oppora, 9 Influno, 35 Reachoutly, 10 LeadFuze, 17 Distribute, 13 Semrush, 10 FreebiesMockup, 15 Maildoso, 16 Scalelist, 12 SellingSignals, 6 Outboundly, 7 EmailSneak, 72 FirstSales72, 15 Close, 112 Follow-up guides, 1 Artisan stats page, 8 Autobound, 6 Saleshandy tips, 1 lemlist structure, 39 Structure and sequence guides). Hunter counts come from keyword and length analysis of all 510 plus a read of 124, so treat them as estimates.

| Rank | Principle | Count | Sources |
|---|---|---|---|
| 1 | Effort reduction (short, one idea per sentence) | 1428 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, Coursera, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Breakcold, Truelist, Datalane, Salesforge, Salesbread, DemandCurve, Outplay, Cleverly, Artisan, Mailsuite, Reachly, LeadSquared, Salesdorado, TextMagic, ProProfsDesk, BluLeadz, Waalaxy, Clearout, LeadGibbon, Starnus, MailGenius, Oppora, Influno, Reachoutly, LeadFuze, Distribute, Semrush, FreebiesMockup, Maildoso, Scalelist, SellingSignals, Outboundly, EmailSneak, FirstSales72, Follow-up guides, Saleshandy tips, Structure and sequence guides |
| 2 | Commitment minimization (low-friction, time-boxed ask) | 998 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, Coursera, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Breakcold, Truelist, Datalane, Salesforge, Salesbread, DemandCurve, Outplay, Cleverly, Artisan, Mailsuite, Reachly, LeadSquared, Salesdorado, TextMagic, ProProfsDesk, BluLeadz, Waalaxy, Clearout, LeadGibbon, Starnus, MailGenius, Oppora, Influno, Reachoutly, LeadFuze, Distribute, Semrush, FreebiesMockup, Maildoso, Scalelist, SellingSignals, Outboundly, EmailSneak, FirstSales72, Follow-up guides, Autobound, Saleshandy tips, lemlist structure, Structure and sequence guides |
| 3 | Specificity (observed trigger plus concrete details) | 679 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, Coursera, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Breakcold, Truelist, Datalane, Salesforge, Salesbread, DemandCurve, Outplay, Cleverly, Artisan, Mailsuite, Reachly, LeadSquared, Salesdorado, TextMagic, ProProfsDesk, BluLeadz, Waalaxy, Clearout, LeadGibbon, Starnus, MailGenius, Oppora, Influno, Reachoutly, Distribute, Semrush, FreebiesMockup, Maildoso, Scalelist, SellingSignals, Outboundly, EmailSneak, FirstSales72, Follow-up guides, Autobound, Saleshandy tips, Structure and sequence guides |
| 4 | Social proof (named or similar company, bandwagon, testimonials) | 418 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, Coursera, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Breakcold, Truelist, Datalane, Salesforge, Salesbread, DemandCurve, Outplay, Cleverly, Artisan, Mailsuite, Reachly, LeadSquared, Salesdorado, TextMagic, ProProfsDesk, BluLeadz, Waalaxy, Clearout, LeadGibbon, Starnus, MailGenius, Influno, Reachoutly, LeadFuze, Distribute, Semrush, FreebiesMockup, Maildoso, SellingSignals, Outboundly, FirstSales72, Follow-up guides, Autobound, Structure and sequence guides |
| 5 | Reciprocity (value before ask) | 305 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, Coursera, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Breakcold, Truelist, Datalane, Salesforge, Salesbread, DemandCurve, Outplay, Cleverly, Artisan, Mailsuite, Reachly, LeadSquared, TextMagic, ProProfsDesk, BluLeadz, Waalaxy, Clearout, LeadGibbon, Starnus, MailGenius, Oppora, Influno, Reachoutly, Distribute, Semrush, Maildoso, Scalelist, SellingSignals, EmailSneak, FirstSales72, Follow-up guides |
| 6 | Consistency (reference a prior touch) | 290 | Salesloft, Woodpecker, ZoomInfo, FirstSales, Smartlead, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Truelist, Datalane, Salesbread, DemandCurve, Cleverly, Mailsuite, Reachly, LeadSquared, Salesdorado, TextMagic, ProProfsDesk, BluLeadz, Waalaxy, Clearout, LeadGibbon, Oppora, Influno, LeadFuze, Semrush, FreebiesMockup, SellingSignals, Outboundly, Follow-up guides, Structure and sequence guides |
| 7 | Quantified benefit | 266 | Woodpecker, Coursera, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, SmartReach, Breakcold, Truelist, Datalane, Salesforge, Salesbread, DemandCurve, Outplay, Cleverly, Artisan, Mailsuite, Reachly, LeadSquared, Salesdorado, Waalaxy, Clearout, LeadGibbon, Starnus, Reachoutly, Semrush, FreebiesMockup, Maildoso, SellingSignals, Outboundly, EmailSneak, FirstSales72, Follow-up guides, Autobound |
| 8 | Easy exit (breakup, wrong-person check, polite out) | 184 | Clay, Apollo, Woodpecker, ZoomInfo, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Hunter, Saleshandy, SmartReach, Datalane, Salesbread, Cleverly, Reachly, Salesdorado, TextMagic, BluLeadz, Waalaxy, Clearout, LeadGibbon, MailGenius, Oppora, Influno, Reachoutly, LeadFuze, Distribute, Semrush, Scalelist, EmailSneak, FirstSales72, Follow-up guides, Structure and sequence guides |
| 9 | Intent signal (they visited or downloaded) | 146 | Salesloft, ZoomInfo, Coursera, FirstSales, Smartlead, SmartWriter, HubSpot, Proposify, Hunter, Breakcold, Truelist, Datalane, Salesbread, Reachly, LeadSquared, Salesdorado, TextMagic, BluLeadz, Waalaxy, LeadGibbon, Starnus, MailGenius, Oppora, Reachoutly, Distribute, Maildoso, Scalelist, SellingSignals, FirstSales72, Follow-up guides |
| 10 | Curiosity gap (including question subjects) | 142 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Saleshandy, Breakcold, Truelist, Datalane, Salesforge, Outplay, Cleverly, Artisan, TextMagic, ProProfsDesk, Waalaxy, Clearout, LeadGibbon, Starnus, MailGenius, Oppora, Influno, Reachoutly, Distribute, Scalelist, FirstSales72, Follow-up guides, Autobound |
| 11 | Liking through a specific compliment | 114 | Salesloft, Woodpecker, ZoomInfo, Coursera, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Saleshandy, SmartReach, Salesforge, Salesbread, DemandCurve, Outplay, Artisan, LeadSquared, TextMagic, BluLeadz, Waalaxy, Clearout, LeadGibbon, Starnus, Influno, Reachoutly, Semrush, FreebiesMockup, Outboundly, EmailSneak, lemlist structure |
| 12 | Lighter ask (offer a smaller version of the ask) | 109 | Hunter, Saleshandy, Truelist, Cleverly, Reachly, Salesdorado, MailGenius, Influno, Reachoutly, Distribute, Scalelist, EmailSneak, Follow-up guides |
| 13 | Normalization (shared problem) | 71 | Salesloft, Coursera, Saleshandy, Truelist, Datalane, Salesforge, Cleverly, Reachly, LeadSquared, Salesdorado, ProProfsDesk, BluLeadz, Waalaxy, LeadGibbon, Starnus, MailGenius, Oppora, Reachoutly, Distribute, Scalelist, SellingSignals, EmailSneak |
| 14 | Borrowed trust (referral or mutual contact) | 58 | Apollo, Salesloft, Woodpecker, ZoomInfo, Coursera, Smartlead, SmartWriter, Cognism, HubSpot, Hunter, SmartReach, Breakcold, Truelist, Salesbread, Cleverly, Artisan, LeadSquared, Salesdorado, TextMagic, ProProfsDesk, Clearout, LeadGibbon, Starnus, MailGenius, Influno, Reachoutly, Distribute, FreebiesMockup, Maildoso, FirstSales72 |
| 15 | Problem agitation | 58 | Woodpecker, ZoomInfo, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Saleshandy, Truelist, Cleverly, Artisan, TextMagic, ProProfsDesk, Waalaxy, LeadGibbon, Starnus, MailGenius, Reachoutly, Distribute, SellingSignals, FirstSales72, Structure and sequence guides |
| 16 | Competitive comparison (peer benchmark) | 52 | Apollo, Salesloft, ZoomInfo, Smartlead, SmartWriter, Cognism, LeadsMonky, Warmupinbox, HubSpot, Proposify, Saleshandy, Truelist, DemandCurve, Outplay, Reachly, Waalaxy, Clearout, LeadGibbon, Starnus, Reachoutly, Semrush, FirstSales72 |
| 17 | Scarcity and urgency | 43 | Woodpecker, ZoomInfo, Coursera, LeadsMonky, SmartReach, Salesbread, DemandCurve, Outplay, Artisan, Mailsuite, ProProfsDesk, Waalaxy, Clearout, Reachoutly, Distribute, FreebiesMockup, SellingSignals, Follow-up guides |
| 18 | Self-aware honesty (acknowledge the interruption) | 43 | Woodpecker, ZoomInfo, FirstSales, Smartlead, SmartWriter, Cognism, LeadsMonky, HubSpot, Proposify, Saleshandy, Breakcold, Truelist, Reachly, Salesdorado, Waalaxy, LeadGibbon, MailGenius, LeadFuze, EmailSneak, Follow-up guides |
| 19 | Loss aversion (cost of inaction) | 40 | Clay, Apollo, ZoomInfo, Smartlead, HubSpot, Cleverly, Artisan, LeadSquared, Starnus, FirstSales72, Follow-up guides, Autobound |
| 20 | Risk reversal (low-stakes framing, no reply needed) | 37 | HubSpot, Proposify, Datalane, DemandCurve, Cleverly, Artisan, Mailsuite, Reachly, ProProfsDesk, Waalaxy, Oppora, Reachoutly, Scalelist |
| 21 | Authority (association, expertise, original data, experience) | 34 | Clay, Apollo, Salesloft, Woodpecker, ZoomInfo, SmartWriter, Cognism, Saleshandy, Salesbread, DemandCurve, Outplay, Cleverly, Mailsuite, LeadSquared, TextMagic, LeadGibbon, Semrush, EmailSneak |
| 22 | Mutual benefit (win-win swap) | 34 | SmartWriter, Warmupinbox, Saleshandy, Breakcold, Salesforge, DemandCurve, LeadSquared, BluLeadz, Waalaxy, Clearout, Influno, Semrush, Maildoso, Outboundly, lemlist structure |
| 23 | Forced choice (two specific options) | 33 | Salesloft, FirstSales, Smartlead, SmartWriter, Cognism, Warmupinbox, HubSpot, Proposify, Salesbread, Reachly, Salesdorado, TextMagic, BluLeadz, LeadGibbon, LeadFuze, Scalelist |
| 24 | Empathy (name the feeling) | 26 | Woodpecker, Smartlead, SmartWriter, Cognism, Warmupinbox, HubSpot, Proposify, Saleshandy, Artisan, LeadSquared, Follow-up guides |
| 25 | No-ask framing (say outright that you want nothing) | 24 | ZoomInfo, Truelist, Datalane, Salesforge, Artisan, Reachly, Waalaxy, Starnus, Oppora, Reachoutly, Distribute, Scalelist, EmailSneak |
| 26 | Humor and playfulness | 23 | Cognism, HubSpot, Proposify, Breakcold, Salesbread, DemandCurve, Artisan, Waalaxy, SellingSignals |
| 27 | Unique mechanism (one claim competitors cannot make) | 17 | Clay, Apollo, ZoomInfo, Smartlead, SmartWriter, Warmupinbox, Datalane |
| 28 | Show the work (a concrete idea or draft) | 15 | Hunter, Reachly, BluLeadz, Influno |
| 29 | Similarity (shared role or interest) | 14 | Woodpecker, Cognism, Proposify, Breakcold, Salesforge, Outplay, LeadSquared, BluLeadz, Waalaxy, Clearout |
| 30 | Exclusivity (confidential or selective opportunity) | 14 | Smartlead, SmartWriter, Mailsuite, LeadSquared, ProProfsDesk, Clearout, Reachoutly, Semrush |
| 31 | Contrarian angle (common approach is weak) | 10 | Apollo, SmartWriter, HubSpot, Proposify, Datalane, Salesdorado, MailGenius |
| 32 | Personal video (humanization) | 7 | Salesloft, HubSpot, Proposify, Follow-up guides |
| 33 | Objection pre-emption (name the doubt first) | 6 | HubSpot, DemandCurve, BluLeadz |
| 34 | Reminder of prior interest | 5 | Woodpecker, Salesbread |
| 35 | Convenience and accommodation (offer to come to them, flexible times) | 5 | Coursera, Salesforge, DemandCurve |
| 36 | Assumptive close (risky, use with care) | 3 | Woodpecker |
| 37 | Topical hook (ride a subject they already care about) | 3 | Clay, Outplay |
| 38 | Price transparency | 2 | Salesloft, DemandCurve |
| 39 | No-oriented question (a "no" is easy to give) | 1 | Salesloft |
| 40 | Peer norm (most people reply). Risky, only with real data | 1 | Cognism |
| 41 | Custom calculation (do the math for them) | 1 | HubSpot |

Counts are a judgment call per email, and the Woodpecker counts are approximate. Woodpecker templates are generic and many are warm follow-ups, so treat its principles as weaker evidence than a real campaign result. None of the early sources gives results for individual emails. [Correction, 2026-10-29: the original sentence said "None of the four sources gives results for individual emails", written when only four sources had been studied. The library now draws on 120 sources. Most still give no per-email results; later ones mostly quote unverified vendor statistics, and a few (for example Belkins, Hunter and ReplyLead) report first-party aggregate data, not results for individual emails.]

## How to apply each one

**Effort reduction.** Keep it short enough to read in about 20 seconds. Cut any sentence that does not earn its place.

**Specificity.** Open with something observed about the prospect: a job post, a hiring spree, a funding event, their website, a post, a podcast, a listing, a metric change. State what it likely means for them. Add a number only if it is real.

**Commitment minimization.** Make the first yes tiny. Name a short duration ("2 minutes", "10 minutes") or offer something small to receive. A small ask beats "can we book 30 minutes?"

**Curiosity gap.** Tease a result, a method or a list without giving everything. A question in the subject line works when it speaks to their real situation.

**Reciprocity.** Give something useful and free first: a short video, a breakdown, an insight, a curated list, a free session, or ideas written for their business. Then ask.

**Social proof.** Best is a company the prospect knows plus a result and timeframe. Next best is a similar company, or the fact that peers are adopting something. Never invent names or numbers.

**Consistency.** In a follow-up, refer to the earlier message in one short line, then add something new. It reads as one conversation, not a nag.

**Authority.** Mention real, verifiable groups you have worked with, original data or research, or years of experience in their market. Vague claims ("leading firm") carry little weight.

**Scarcity and urgency.** Use real deadlines only (an event date, an offer end date). Fake urgency or repeating "last chance" erodes trust. Warmupinbox advises urgency lines such as "limited spots available" (unverified), while other sources in this repo warn against urgency in cold email, so only use it when it is true.

**Unique mechanism.** Name the one thing you do that a competitor cannot say. Concrete beats generic.

**Empathy.** Name the feeling or difficulty in one line ("a tough market", "frustrating when a listing stalls") before the offer. Keep it short and sincere.

**Liking through a specific compliment.** Praise something real and specific they made or said, such as a podcast episode or a project. Generic praise reads as flattery.

**Problem agitation.** Describe the cost of the problem once, vividly, then offer relief. Do not insult them or exaggerate.

**Borrowed trust.** Use a real mutual contact who agreed to be named. Never imply a referral that did not happen.

**Loss aversion.** Ask a question that shows what they lose by waiting, such as time, money, or missed pipeline. Phrase it as a question, not an accusation.

**Easy exit.** In a final follow-up, ask who else should handle this, or give a polite way out. It takes pressure off and often routes you to the right person.

**Self-aware honesty.** A line like "you probably get many emails like this" can lower defenses. Keep it light and move on to the point.

**Contrarian angle.** Say the usual approach falls short, then hint at a different one. Only use it if you can back the claim up.

**Competitive comparison.** Show how a similar company is doing and how that compares to the prospect's goal. Executives watch peers closely.

**Similarity.** Mention a real shared role, interest or connection. Do not invent common ground.

**Quantified benefit.** Attach a real, believable number to a benefit. Do not promise a guaranteed result.

**Assumptive close (risky).** Lines that assume they will talk (a tag question like "right?" after the ask) can work with a warm lead but read as pressure in cold email. Prefer a real question.

**Forced choice.** Offer two specific options (two days, two formats) instead of an open "when are you free?".

**Normalization.** Say that many people in their role face the same problem. It makes admitting the problem feel safe. Name one real problem, not a vague one.

**Reminder of prior interest.** In a warm follow-up, mention what the person already liked or asked about so the email feels personal.

**Personal video.** A short intro video makes the email feel human. Best for warm leads who already showed interest.

**Intent signal.** When a prospect visited your site or downloaded something, say what you noticed and offer the next step. Only use this for real behavior.

**No-oriented question.** A question where "no" is the easy, safe answer can lower resistance. Keep the wording simple to avoid double negatives.

**Price transparency.** Be open about pricing when the buyer is already evaluating. It builds trust but is too much for a first cold email.

**Lighter ask.** Offer a smaller version of the ask: an email answer instead of a call, one specific question, or a single-sentence reply. Hunter's curated set uses this in advice requests, testimonial requests and follow-ups.

**Show the work.** When asking for an opportunity (an internship, a guest post, a link), hand over a concrete idea or finished draft instead of a general wish. It proves effort and lets them react to something real.

**Objection pre-emption.** Name the doubt they are probably having ("another sales email") and say why this one differs. Use a real difference, such as no long contract.

**Risk reversal.** Make the downside feel small: say no reply is needed, or that the worst case is 15 minutes. It lowers the stakes of replying.

**Custom calculation.** Do the math for them with their size and industry, show the assumptions and offer the full workings. Never invent the inputs. A real calculation shows homework and gives a number to react to.

**Peer norm (risky).** Telling someone that most people like them reply can nudge a reply, but only with a real statistic. Cognism's example uses an invented reply-chance figure and admits it is for effect. Do not invent numbers.

**Humor and playfulness.** A light joke in a break-up or P.S. can make you memorable. Use it sparingly and only when it fits your brand and the prospect, since jokes can look flippant.

**Mutual benefit.** Offer a win-win, such as swapping audiences with a non-competing business, so both sides gain. Back it with a real past example.

**Exclusivity.** Signal that the opportunity is private or selective (a confidential search for a specific profile). Use it only when it is true, and do not overstate what the role or offer is.

**Convenience and accommodation.** Make saying yes easy by offering to come to them or work around their schedule ("I will be in your city next week", "any time that suits you"). Tie it to a real reason, such as a trip you are actually taking.

**No-ask framing.** Say plainly that you want nothing in return. It removes pressure and positions you as a resource. Pair it with a specific compliment or useful finding, and follow up later with a real ask.

**Topical hook.** Tie the email to a subject already on their mind, then connect it to a concrete offer. Avoid broad hype with no link to their business.
